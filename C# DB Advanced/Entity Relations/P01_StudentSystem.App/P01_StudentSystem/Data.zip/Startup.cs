﻿namespace P01_StudentSystem
{
    public class Startup
    {
        public static void Main(string[] args)
        {
           
        }
    }
}
