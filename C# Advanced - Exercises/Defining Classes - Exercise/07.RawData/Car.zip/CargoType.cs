﻿namespace _07.RawData;

public enum CargoType
{
    fragile,
    flammable
}
