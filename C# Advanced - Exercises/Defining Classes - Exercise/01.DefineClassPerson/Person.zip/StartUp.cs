﻿namespace DefiningClasses;

public class StartUp
{
    static void Main(string[] args)
    {
        var person = new Person();
    }
}

