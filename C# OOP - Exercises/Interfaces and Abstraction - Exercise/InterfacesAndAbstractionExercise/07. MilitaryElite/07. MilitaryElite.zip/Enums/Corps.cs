﻿namespace _07._MilitaryElite.Enums;
public enum Corps
{
    Airforces,
    Marines
}
