﻿namespace _04.BorderControl;

public interface IRobot
{
    string Model { get; }
}