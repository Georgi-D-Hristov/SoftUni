﻿namespace _04.BorderControl;

public interface IHuman
{
    string Name { get; }
    int Age { get; set; }
}