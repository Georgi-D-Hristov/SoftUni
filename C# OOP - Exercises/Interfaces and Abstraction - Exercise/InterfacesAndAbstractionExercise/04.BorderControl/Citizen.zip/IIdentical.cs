﻿namespace _04.BorderControl;

public interface IIdentical
{
    string Id { get; }
}