﻿namespace _04.BorderControl;

public interface IVisitors
{
    void ValidateId(string pattern);
}