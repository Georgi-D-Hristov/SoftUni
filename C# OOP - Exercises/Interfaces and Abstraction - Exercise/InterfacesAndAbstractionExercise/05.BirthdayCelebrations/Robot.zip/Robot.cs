﻿namespace _05.BirthdayCelebrations;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Robot : IIdentical
{
    public string Model { get; init; }
    public string Id { get; init; }
}

