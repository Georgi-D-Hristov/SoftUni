﻿namespace _04.WildFarm.Contracts
{
    public interface IFood
    {
        int Quantity { get; init; }
    }
}