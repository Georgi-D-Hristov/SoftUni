﻿namespace _04.WildFarm.Contracts
{
    public interface IProduceSound
    {
        string Sound();
    }
}