﻿namespace PizzaCalories
{
    public class Dough
    {
        public Dough()
        {
            
        }
        public double FlourType { get; }

        public double BakingTechnique { get;}

        public double Calories { get; }
    }
}
